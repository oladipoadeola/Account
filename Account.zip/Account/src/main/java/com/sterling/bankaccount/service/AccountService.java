package com.sterling.bankaccount.service;

import com.sterling.bankaccount.domain.Account;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AccountService extends CrudRepository<Account, Long> {
}