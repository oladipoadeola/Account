package com.sterling.bankaccount.controller;

import com.sterling.bankaccount.service.AccountService;
import com.sterling.bankaccount.service.TransactionsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;


public class BaseControllerTests {

    @Autowired
    protected MockMvc mvc;

    @MockBean
    protected AccountService accountService;

    @MockBean
    protected TransactionsService transactionsService;

}